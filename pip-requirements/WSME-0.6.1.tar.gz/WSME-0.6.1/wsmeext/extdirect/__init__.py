from wsmeext.extdirect.protocol import ExtDirectProtocol  # noqa

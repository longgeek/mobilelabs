TODO
====

WSME is a work in progress. Here is a list of things that should
be done :

-   Use gevents for batch-calls

-   Implement new protocols :

    -   json-rpc

    -   xml-rpc

-   Implement adapters for other frameworks :

    -   TurboGears 2

    -   Pylons

    -   CherryPy

    -   Flask

    -   others ?

-   Add unittests for adapters

-   Address the authentication subject (which should be handled by
    some other wsgi framework/middleware, but a little integration
    could help).

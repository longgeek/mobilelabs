Getting Started
===============

For now here is just a working example.
You can find it in the examples directory of the source distribution.

.. literalinclude:: ../examples/demo/demo.py
    :language: python

When running this example, the following soap client can interrogate
the web services:

.. literalinclude:: ../examples/demo/client.py
    :language: python


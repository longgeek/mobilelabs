========
Usage
========

To use  in a project::

	import vmware
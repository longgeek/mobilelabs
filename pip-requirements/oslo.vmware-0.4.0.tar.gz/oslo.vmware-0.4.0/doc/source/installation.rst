============
Installation
============

At the command line::

    $ pip install 

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv 
    $ pip install 
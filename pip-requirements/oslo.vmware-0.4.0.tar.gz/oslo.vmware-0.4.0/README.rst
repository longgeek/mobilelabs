===================================
oslo.vmware
===================================

Oslo VMware library for OpenStack projects

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/oslo.vmware

Features
--------

* TODO
taskflow.persistence.backends package
=====================================

Subpackages
-----------

.. toctree::

    taskflow.persistence.backends.sqlalchemy

Submodules
----------

taskflow.persistence.backends.base module
-----------------------------------------

.. automodule:: taskflow.persistence.backends.base
    :members:
    :undoc-members:
    :show-inheritance:

taskflow.persistence.backends.impl_dir module
---------------------------------------------

.. automodule:: taskflow.persistence.backends.impl_dir
    :members:
    :undoc-members:
    :show-inheritance:

taskflow.persistence.backends.impl_memory module
------------------------------------------------

.. automodule:: taskflow.persistence.backends.impl_memory
    :members:
    :undoc-members:
    :show-inheritance:

taskflow.persistence.backends.impl_sqlalchemy module
----------------------------------------------------

.. automodule:: taskflow.persistence.backends.impl_sqlalchemy
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: taskflow.persistence.backends
    :members:
    :undoc-members:
    :show-inheritance:

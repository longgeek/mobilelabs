taskflow.patterns package
=========================

Submodules
----------

taskflow.patterns.graph_flow module
-----------------------------------

.. automodule:: taskflow.patterns.graph_flow
    :members:
    :undoc-members:
    :show-inheritance:

taskflow.patterns.linear_flow module
------------------------------------

.. automodule:: taskflow.patterns.linear_flow
    :members:
    :undoc-members:
    :show-inheritance:

taskflow.patterns.unordered_flow module
---------------------------------------

.. automodule:: taskflow.patterns.unordered_flow
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: taskflow.patterns
    :members:
    :undoc-members:
    :show-inheritance:

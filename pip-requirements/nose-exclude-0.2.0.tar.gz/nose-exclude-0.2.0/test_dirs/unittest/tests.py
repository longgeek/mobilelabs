import unittest

class UnitTests(unittest.TestCase):
    def test_a(self):
        assert True

    def test_b(self):
        assert True

    @staticmethod
    def test_e(self):
        assert True

def test_c():
    assert True

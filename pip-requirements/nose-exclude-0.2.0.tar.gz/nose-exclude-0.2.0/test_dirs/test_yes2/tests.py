
def test_fish_dont_run():
    return False

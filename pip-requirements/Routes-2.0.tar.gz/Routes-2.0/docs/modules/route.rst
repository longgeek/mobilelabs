:mod:`routes.route` -- Route
============================

.. automodule:: routes.route

Module Contents
---------------

.. autoclass:: Route
    :members:
    :undoc-members:

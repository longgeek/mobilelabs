:mod:`routes.lru` -- LRU caching class and decorator
====================================================

.. automodule:: routes.lru

Module Contents
---------------

.. autoclass:: LRUCache

:mod:`routes.middleware` -- Routes WSGI Middleware
==================================================

.. automodule:: routes.middleware

Module Contents
---------------

.. autoclass:: RoutesMiddleware
    :members:
    :undoc-members:
.. autofunction:: is_form_post

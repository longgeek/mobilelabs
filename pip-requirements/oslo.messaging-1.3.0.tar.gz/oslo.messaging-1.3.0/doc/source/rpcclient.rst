----------
RPC Client
----------

.. currentmodule:: oslo.messaging

.. autoclass:: RPCClient
   :members:

.. autoexception:: RemoteError

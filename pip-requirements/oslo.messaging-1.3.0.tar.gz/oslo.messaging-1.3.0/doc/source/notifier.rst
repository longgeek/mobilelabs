--------
Notifier
--------

.. currentmodule:: oslo.messaging

.. autoclass:: Notifier
   :members:

.. autoclass:: LoggingNotificationHandler
   :members:

.. autoclass:: PublishErrorsHandler
   :members:

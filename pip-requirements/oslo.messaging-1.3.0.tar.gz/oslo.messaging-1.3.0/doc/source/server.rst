------
Server
------

.. automodule:: oslo.messaging.rpc.server

.. currentmodule:: oslo.messaging

.. autofunction:: get_rpc_server

.. autoclass:: RPCDispatcher

.. autoclass:: MessageHandlingServer
   :members:

.. autofunction:: expected_exceptions

.. autoexception:: ExpectedException

.. autofunction:: get_local_context

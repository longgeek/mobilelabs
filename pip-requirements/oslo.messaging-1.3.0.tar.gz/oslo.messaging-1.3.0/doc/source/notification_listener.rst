---------------------
Notification Listener
---------------------

.. automodule:: oslo.messaging.notify.listener

.. currentmodule:: oslo.messaging

.. autofunction:: get_notification_listener

.. autoclass:: MessageHandlingServer
   :members:

.. autofunction:: get_local_context

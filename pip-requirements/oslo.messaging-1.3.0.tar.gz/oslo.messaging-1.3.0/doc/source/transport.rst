---------
Transport
---------

.. currentmodule:: oslo.messaging

.. autofunction:: get_transport

.. autoclass:: Transport

.. autoclass:: TransportURL
   :members:

.. autoclass:: TransportHost

.. autofunction:: set_transport_defaults

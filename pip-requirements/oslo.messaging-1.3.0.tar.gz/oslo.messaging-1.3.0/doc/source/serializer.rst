----------
Serializer
----------

.. currentmodule:: oslo.messaging

.. autoclass:: Serializer
   :members:

.. autoclass:: NoOpSerializer

----------------------
Testing Configurations
----------------------

.. currentmodule:: oslo.messaging.conffixture

.. autoclass:: ConfFixture
   :members:


These are to be placed in a directory *above* source repos.

Edit the genconfs.sh line near the top that lists projects, for testing.

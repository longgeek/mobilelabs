These files are copied from the following locations:
* docbookxi.rng: http://docbook.org/xml/5.1CR1/rng/docbookxi.rng
* extensions.rng: clouddocs-maven-plugin
* rackbook.rng: clouddocs-maven-plugin
* wadl.rng: clouddocs-maven-plugin
* wadl.xsd: http://docs.rackspace.com/rackbook/wadl.xsd
* xml.xsd: http://docs.rackspace.com/rackbook/xml.xsd

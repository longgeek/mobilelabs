========
Usage
========

To use openstack-doc-tools in a project::

	import os_doc_tools

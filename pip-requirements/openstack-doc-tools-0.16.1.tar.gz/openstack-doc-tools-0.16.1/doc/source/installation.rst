============
Installation
============

At the command line::

    $ pip install openstack-doc-tools

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv openstack-doc-tools
    $ pip install openstack-doc-tools

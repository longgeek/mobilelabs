.. _using-git:

Working with *networkx* source code
================================================

Contents:

.. toctree::
   :maxdepth: 2

   git_intro
   git_install
   following_latest
   patching
   git_development
   git_resources



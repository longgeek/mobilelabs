.. _tree:

Tree
====

.. toctree::
   :maxdepth: 2

Recognition
-----------
.. automodule:: networkx.algorithms.tree.recognition
.. autosummary::
   :toctree: generated/

   is_tree
   is_forest

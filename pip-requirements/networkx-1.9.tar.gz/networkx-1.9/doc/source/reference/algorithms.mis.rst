***********************
Maximal independent set
***********************

.. automodule:: networkx.algorithms.mis
.. autosummary::
   :toctree: generated/

   maximal_independent_set


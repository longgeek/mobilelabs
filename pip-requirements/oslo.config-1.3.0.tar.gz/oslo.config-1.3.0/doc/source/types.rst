---------------------------
Option Types and Validation
---------------------------

.. automodule:: oslo.config.types
   :members:

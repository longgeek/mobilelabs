========
 PyCADF
========

see the ReleaseNotes document and the project home for more info.

  http://launchpad.net/pycadf

Specification details can be found here: http://www.dmtf.org/standards/cadf

Developer details can be found here: http://docs.openstack.org/developer/pycadf
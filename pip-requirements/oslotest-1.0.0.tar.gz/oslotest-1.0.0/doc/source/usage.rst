========
Usage
========

To use  in a project::

    from oslotest import base


    class MyTest(base.BaseTestCase):

        def test_something(self):
            self.assertTrue(True)

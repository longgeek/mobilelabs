Unit tests
==========

1. pip install nose
2. pip install nose-testconfig
3. use config.ini to configure unit tests
3. run tests with nosetests --tc-file config.ini

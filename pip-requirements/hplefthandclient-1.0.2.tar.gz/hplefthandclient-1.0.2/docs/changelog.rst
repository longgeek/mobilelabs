Changelog
=========


Changes in Version 1.0.0
------------------------

- First implementation of the REST API Client

Changes in Version 1.0.1
------------------------

- Updated the REST API Client to be Python 3.0 compliant

Changes in Version 1.0.2
------------------------

- Added support for query parameter in getVolume


:mod:`client` -- HPLeftHandClient
=================================

.. automodule:: hplefthandclient
   :synopsis: HP LeftHand REST Web client

   .. autodata:: version


Sub-modules:

.. toctree::
   :maxdepth: 2

   client
   exceptions
   http


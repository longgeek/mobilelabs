:mod:`exceptions` -- HTTP Exceptions
====================================================

.. automodule:: hplefthandclient.exceptions
   :synopsis: HTTP Exceptions

   .. autoclass:: hplefthandclient.exceptions.HTTPNotFound
   .. autoclass:: hplefthandclient.exceptions.HTTPBadRequest

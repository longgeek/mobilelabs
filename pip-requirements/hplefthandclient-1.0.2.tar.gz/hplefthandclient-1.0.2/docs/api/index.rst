API Documentation
=================

The HP LeftHand Client package contains a :mod:`hplefthandclient` class which extends a more
generic :mod:`http` class for doing REST calls

.. toctree::
   :maxdepth: 2

   hplefthandclient/index


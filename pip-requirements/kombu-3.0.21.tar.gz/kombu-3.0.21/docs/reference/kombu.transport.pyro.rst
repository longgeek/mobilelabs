.. currentmodule:: kombu.transport.pyro

.. automodule:: kombu.transport.pyro

    .. contents::
        :local:

    Transport
    ---------

    .. autoclass:: Transport
        :members:
        :undoc-members:

    Channel
    -------

    .. autoclass:: Channel
        :members:
        :undoc-members:

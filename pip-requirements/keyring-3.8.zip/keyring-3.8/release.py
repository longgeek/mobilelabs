"""
Keyring is released using 'jaraco.packaging.release'. To make a release,
install jaraco.packaging and run 'python -m jaraco.packaging.release'
"""

test_info = "Travis-CI tests: http://travis-ci.org/#!/jaraco/keyring"

# flake8: noqa
from keystoneclient.v3.client import Client


__all__ = [
    'client',
]

=======================================================
 cliff -- Command Line Interface Formulation Framework
=======================================================

cliff is a framework for building command line programs. It uses
setuptools entry points to provide subcommands, output formatters, and
other extensions.

* Free software: Apache license
* Documentation: http://cliff.readthedocs.org
* Source: http://git.openstack.org/cgit/openstack/cliff
* Bugs: https://bugs.launchpad.net/python-cliff

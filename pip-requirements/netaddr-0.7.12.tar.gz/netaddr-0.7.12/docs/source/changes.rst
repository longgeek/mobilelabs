============================
What's new in netaddr 0.7.12
============================

.. include:: ../../CHANGELOG

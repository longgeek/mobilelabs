stevedore
=========

Manage dynamic plugins for Python applications

* Free software: Apache license
* Documentation: http://stevedore.readthedocs.org
* Source: http://git.openstack.org/cgit/openstack/stevedore
* Bugs: https://bugs.launchpad.net/python-stevedore


.. _account_and_container_db:

***************************
Account DB and Container DB
***************************

.. _db:

DB
==

.. automodule:: swift.common.db
    :members:
    :undoc-members:
    :show-inheritance:

.. _db-replicator:

DB replicator
=============

.. automodule:: swift.common.db_replicator
    :members:
    :undoc-members:
    :show-inheritance:

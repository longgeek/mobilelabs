.. ref-sqs

====
SQS 
====

boto.sqs
--------

.. automodule:: boto.sqs
   :members:   
   :undoc-members:

boto.sqs.attributes
-------------------

.. automodule:: boto.sqs.attributes
   :members:   
   :undoc-members:

boto.sqs.connection
-------------------

.. automodule:: boto.sqs.connection
   :members:   
   :undoc-members:

boto.sqs.jsonmessage
--------------------

.. automodule:: boto.sqs.jsonmessage
   :members:   
   :undoc-members:

boto.sqs.message
----------------

.. automodule:: boto.sqs.message
   :members:   
   :undoc-members:

boto.sqs.queue
--------------

.. automodule:: boto.sqs.queue
   :members:   
   :undoc-members:

boto.sqs.regioninfo
-------------------

.. automodule:: boto.sqs.regioninfo
   :members:   
   :undoc-members:

boto.sqs.batchresults
---------------------

.. automodule:: boto.sqs.batchresults
   :members:   
   :undoc-members:

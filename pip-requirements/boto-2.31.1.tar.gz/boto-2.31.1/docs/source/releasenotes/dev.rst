boto v2.xx.x
============

:date: 2013/xx/xx

This release adds ____.


Features
--------

* . (:issue:``, :sha:``)


Bugfixes
--------

* (:issue:``, :sha:``)
* Several documentation improvements/fixes:

    * (:issue:``, :sha:``)
